<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo_list";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add a new task
if (isset($_POST['task'])) {
    $task = $_POST['task'];
    
    // Insert the task into the database
    $sql = "INSERT INTO tasks (task_text) VALUES ('$task')";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['message'] = "Task added successfully.";
    } else {
        $_SESSION['message'] = "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Remove a task
if (isset($_GET['remove'])) {
    $taskId = $_GET['remove'];
    
    // Delete the task from the database
    $sql = "DELETE FROM tasks WHERE id=$taskId";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['message'] = "Task removed successfully.";
    } else {
        $_SESSION['message'] = "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Display tasks
$tasks = [];
$sql = "SELECT * FROM tasks";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row['task_text'];
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Simple To-Do List with Database</title>
</head>
<body>
    <h1>To-Do List</h1>
    <form action="todo.php" method="post">
        <input type="text" name="task" placeholder="Enter a new task" required>
        <button type="submit">Add Task</button>
    </form>
    
    <ul>
        <?php
        foreach ($tasks as $index => $task) {
            echo "<li>$task <a href='todo.php?remove=$index'>Remove</a></li>";
        }
        ?>
    </ul>
    
    <?php
    if (isset($_SESSION['message'])) {
        echo "<p>" . $_SESSION['message'] . "</p>";
        unset($_SESSION['message']);
    }
    ?>
</body>
</html>
